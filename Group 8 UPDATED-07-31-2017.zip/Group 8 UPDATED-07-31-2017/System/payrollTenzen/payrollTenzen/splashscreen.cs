﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace payrollTenzen
{
    public partial class splashscreen : Form
    {
        public splashscreen()
        {
            InitializeComponent();
            
        }

       
        private void splashscreen_Load(object sender, EventArgs e)
        {

            timer1.Enabled = true;
            timer1.Start();
            timer1.Interval = 1000;
            pb1.Maximum = 20;
            timer1.Tick += new EventHandler(timer1_Tick);
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            {
                label1.Visible = true;
                label1.TextAlign = ContentAlignment.MiddleCenter;
                pb1.Value++;
                if (pb1.Value != 20)
                {
                    if (pb1.Value == 1)
                        label1.Text = "Looking For Resources...";
                    if (pb1.Value == 5)
                        label1.Text = "Downloading Data...";
                    if (pb1.Value == 10)
                        label1.Text = "Getting Information...";
                    if (pb1.Value == 15)
                        label1.Text = "Will Be Ready In Any Moment...";
                    if (pb1.Value == 20)
                        label1.Text = "Starting System";
                }
                else
                {
                    timer1.Stop();
                    Login frm = new Login();
                    this.Visible = false;
                    frm.Show();
                }
            }
        }

    }
}
